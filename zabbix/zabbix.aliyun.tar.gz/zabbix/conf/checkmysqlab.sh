#!/bin/sh 
MYSQL_PWD="zabbix_jg" 
ARGS=1 
if [ $# -ne "$ARGS" ];then 
    echo "Please input one arguement:" 
fi 
case $1 in 
    ABCopy) 
        result=`mysql -uzabbix -pzabbix_jg -h127.0.0.1 -e "show slave status\G;"|grep "Yes"|wc -l`
            echo $result 
            ;; 
#    Com_begin) 
#        result=`mysqladmin -uzabbix -p${MYSQL_PWD} -h127.0.0.1 extended-status |grep -w "Com_begin"|cut -d"|" -f3` 
#                echo $result 
#                ;; 
                        
        *) 
        echo "Usage:$0(ABCopy)" 
        ;; 
esac 
