screen -ls|egrep  "fc" |wc -l
